package com.example.actor

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import android.graphics.Typeface
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.style.StyleSpan
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction


class ActorRecyclerViewAdapter(private var actorList: List<ActorItem>) : RecyclerView.Adapter<ActorRecyclerViewAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.actor_name)
        val detailsTextView: TextView = itemView.findViewById(R.id.actor_detail)
        val profileImageView: ImageView = itemView.findViewById(R.id.actor_headshot)

        init {
            profileImageView.setOnClickListener {
                val actorItem = actorList[adapterPosition]
                val fragmentManager = itemView.context as FragmentActivity
                val fragmentTransaction: FragmentTransaction = fragmentManager.supportFragmentManager.beginTransaction()

                val actorDetailFragment = ActorDetailFragment()
                val bundle = Bundle()
                bundle.putString("actorName", actorItem.name)
                bundle.putString("actorBiography", actorItem.detail)
                bundle.putString("actorProfilePath", actorItem.headshot)

                actorDetailFragment.arguments = bundle

                fragmentTransaction.replace(R.id.content, actorDetailFragment)
                    .addToBackStack(null)
                    .commit()
            }
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.fragment_actor, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val actorItem = actorList[position]
        holder.nameTextView.text = actorItem.name

        if (actorItem.detail.isNotEmpty()) {
            holder.detailsTextView.text = actorItem.detail
            holder.detailsTextView.visibility = View.VISIBLE
        } else {
            holder.detailsTextView.visibility = View.GONE
        }

        val spannableName = SpannableString(actorItem.name)
        spannableName.setSpan(StyleSpan(Typeface.BOLD), 0, spannableName.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        holder.nameTextView.text = spannableName

        val profilePath = actorItem.headshot
        val profileUrl = "https://image.tmdb.org/t/p/w500$profilePath"

        Glide.with(holder.itemView.context)
            .load(profileUrl)
            .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
            .apply(RequestOptions.errorOf(R.drawable.error))
            .into(holder.profileImageView)
    }


    override fun getItemCount(): Int {
        return actorList.size
    }

    fun updateData(newData: List<ActorItem>) {
        actorList = newData
        notifyDataSetChanged()
    }
}
