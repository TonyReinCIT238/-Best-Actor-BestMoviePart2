package com.example.actor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class ActorDetailFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_actor_detail, container, false)

        val actorName = arguments?.getString("actorName")
        val actorBiography = arguments?.getString("actorBiography")
        val actorProfilePath = arguments?.getString("actorProfilePath")

        val nameTextView = view.findViewById<TextView>(R.id.actor_name_detail)
        val biographyTextView = view.findViewById<TextView>(R.id.actor_biography)
        val profileImageView = view.findViewById<ImageView>(R.id.actor_headshot_detail)

        nameTextView.text = actorName

        val profileUrl = "https://image.tmdb.org/t/p/w500$actorProfilePath"
        Glide.with(this)
            .load(profileUrl)
            .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
            .apply(RequestOptions.errorOf(R.drawable.error))
            .into(profileImageView)

        fetchKnownMovies(actorName, biographyTextView)

        return view
    }

    private fun fetchKnownMovies(actorName: String?, biographyTextView: TextView) {
        val apiKey = "a07e22bc18f5cb106bfe4cc1f83ad8ed"
        val client = OkHttpClient()

        val request = Request.Builder()
            .url("https://api.themoviedb.org/3/search/person?api_key=$apiKey&query=$actorName")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                activity?.runOnUiThread {
                    biographyTextView.text = "Movies not available due to network error"
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let { json ->
                    val actorId = extractActorId(json)
                    if (actorId != null) {
                        fetchMoviesForActor(actorId, biographyTextView)
                    } else {
                        activity?.runOnUiThread {
                            biographyTextView.text = "No known movies available"
                        }
                    }
                }
            }
        })
    }

    private fun extractActorId(json: String): Int? {
        val jsonObject = JSONObject(json)
        val resultsArray = jsonObject.optJSONArray("results")
        if (resultsArray != null && resultsArray.length() > 0) {
            val actorObject = resultsArray.optJSONObject(0)
            return actorObject.optInt("id")
        }
        return null
    }

    private fun fetchMoviesForActor(actorId: Int, biographyTextView: TextView) {
        val apiKey = "a07e22bc18f5cb106bfe4cc1f83ad8ed"
        val client = OkHttpClient()

        val request = Request.Builder()
            .url("https://api.themoviedb.org/3/person/$actorId/movie_credits?api_key=$apiKey")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                activity?.runOnUiThread {
                    biographyTextView.text = "Movies not available due to network error"
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let { json ->
                    val movies = parseMoviesFromJson(json)
                    if (movies.isNotEmpty()) {
                        activity?.runOnUiThread {
                            val moviesText = movies.joinToString(separator = ", ")
                            biographyTextView.text = "Known for: $moviesText"
                        }
                    } else {
                        activity?.runOnUiThread {
                            biographyTextView.text = "No known movies available"
                        }
                    }
                }
            }
        })
    }

    private fun parseMoviesFromJson(json: String): List<String> {
        val moviesList = mutableListOf<String>()
        val jsonObject = JSONObject(json)
        val castArray = jsonObject.optJSONArray("cast")

        castArray?.let {
            for (i in 0 until it.length()) {
                val movie = it.optJSONObject(i)
                val movieTitle = movie.optString("title")
                moviesList.add(movieTitle)
            }
        }

        return moviesList
    }
}
