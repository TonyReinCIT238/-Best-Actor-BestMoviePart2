package com.example.actor

data class ActorItem(
    val name: String,
    val detail: String,
    val headshot: String
)
