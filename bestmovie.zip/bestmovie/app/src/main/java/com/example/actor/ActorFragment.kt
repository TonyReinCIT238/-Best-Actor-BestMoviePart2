package com.example.actor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import androidx.recyclerview.widget.GridLayoutManager


class ActorFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var adapter: ActorRecyclerViewAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_actor_list, container, false)

        recyclerView = view.findViewById(R.id.list)
        recyclerView.layoutManager = GridLayoutManager(requireContext(), 2)
        adapter = ActorRecyclerViewAdapter(emptyList())
        recyclerView.adapter = adapter

        swipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout)

        swipeRefreshLayout.setOnRefreshListener {
            fetchPopularActors()
        }

        fetchPopularActors()

        return view
    }


    private fun fetchPopularActors() {
        val apiKey = "a07e22bc18f5cb106bfe4cc1f83ad8ed"
        val page = 1

        val client = OkHttpClient()

        val request = Request.Builder()
            .url("https://api.themoviedb.org/3/person/popular?api_key=$apiKey&page=$page")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                swipeRefreshLayout.isRefreshing = false
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let { json ->
                    val actorList = parseActorData(json)
                    activity?.runOnUiThread {
                        adapter.updateData(actorList)
                        swipeRefreshLayout.isRefreshing = false
                    }
                }
            }
        })
    }

    private fun parseActorData(json: String): List<ActorItem> {
        val actorList = mutableListOf<ActorItem>()

        val jsonObject = JSONObject(json)
        val resultsArray = jsonObject.getJSONArray("results")

        for (i in 0 until resultsArray.length()) {
            val actorObject = resultsArray.getJSONObject(i)
            val name = actorObject.getString("name")
            val details = actorObject.optString(
                "biography",
                ""
            )
            val profilePath = actorObject.getString("profile_path")

            val profileUrl = "https://image.tmdb.org/t/p/w200$profilePath"

            actorList.add(ActorItem(name, details, profileUrl))
        }

        return actorList
    }
}
