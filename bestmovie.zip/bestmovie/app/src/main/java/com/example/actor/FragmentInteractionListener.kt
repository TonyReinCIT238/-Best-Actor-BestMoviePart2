package com.example.actor

interface FragmentInteractionListener {

    fun onItemSelected(itemId: Int)

}
